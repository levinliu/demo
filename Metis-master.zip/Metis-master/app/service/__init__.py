__all__ = ["time_series_detector"]
