

bash ./db/lrun.sh
bash ./srv/lrun.sh
bash ./web/lrun.sh

#visit brower with below link:
curl http://127.0.0.1:18081/