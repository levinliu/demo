docker network create levin-aiops-network


docker network ls
